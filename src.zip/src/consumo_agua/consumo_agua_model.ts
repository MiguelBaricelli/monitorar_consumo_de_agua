

export class ConsumoAgua {
    id: number;
    usuarioId: number;
    quantidade: number; 
    dataLeitura: Date;
  }
  
  